#ifndef _UART_H
#define _UART_H

#include "system.h"



void UartInit(void);
void UartSendByte(uint8_t txbuf);



#endif












