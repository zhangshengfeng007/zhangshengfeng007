#ifndef _TIMER_DRIVER_H
#define _TIMER_DRIVER_H

#include "system.h"


void TIMER0_Configuration(void);
void TIMER1_Configuration(void);
void TIMER2_Configuration(void);

#endif
